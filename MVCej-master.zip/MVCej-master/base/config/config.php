<?php

//define('URL', 'http://localhost/mvc/');
define('URL', 'http://' . $_SERVER['HTTP_HOST'] . '//');

//conexion a la base de datos
define('HOST', 'localhost');
define('PORT_DB', '3307');
define('DB', 'f01');
define('USER', 'root');
define('PASSWORD', '');
define('CHARSET', 'utf8mb4');
