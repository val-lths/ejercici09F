<?php

use Franco\App\libs\App;
require_once 'vendor/autoload.php';
App::iniciar();
