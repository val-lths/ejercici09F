<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>

<body>
  <h1>Hail Hitler </h1>
  <?php
  require 'src/vista/menu.php'; ?>
  <p><?php echo $this->datos; ?></p>
</body>

</html>